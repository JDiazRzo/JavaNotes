package modelo;

public class Isosceles extends Triangulo {
	
	public Isosceles (double ladosIguales, double base){
		super(ladosIguales, ladosIguales, base);
	}
	
	public double sacarArea(){
		double elevado = Math.pow(ladoA, 2);
		double altura = Math.sqrt((elevado) + (ladoC/2));
		return (ladoC * altura)/2;
	}
}
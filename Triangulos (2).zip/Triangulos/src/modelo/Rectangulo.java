package modelo;

public class Rectangulo extends Triangulo {
	
    private double altura;
    private double base;

	public Rectangulo (double altura, double base){
		super(base , altura, Math.sqrt((altura * altura) + (base * base)));
        this.altura = altura;
        this.base = base;
	}
	
	public double sacarArea(){
		double elevado = Math.pow(altura, 2);
		double altura = Math.sqrt((elevado) + (base/2));
		return (base * altura)/2;
	}
}
package modelo;

public class Equilatero extends Triangulo {
	
	public Equilatero (double lado){
		super(lado,lado,lado);
	}
	
	public double sacarArea(){
		double elevado = Math.pow(ladoA, 2);
		double altura = Math.sqrt((elevado) + (ladoA/2));
		return (ladoA * altura)/2;
	}
}
package modelo;

public abstract class Triangulo {
	protected double ladoA;
	protected double ladoB;
	protected double ladoC;

	
	public Triangulo(double ladoA, double ladoB, double ladoC) {
			this.ladoA = ladoA;
			this.ladoB = ladoB;
			this.ladoC = ladoC;
		}

	public double calcularPerimetro() {
		return(ladoA+ ladoB +ladoC);
	}
}

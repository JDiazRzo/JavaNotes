package modelo;

public class Escaleno extends Triangulo {
	
	public Escaleno (double ladoA, double ladoB, double ladoC){
		super(ladoA,ladoB,ladoC);
	}
	
	public double sacarArea(){
		double semiPerimetro = calcularPerimetro()/2;
		return Math.sqrt((semiPerimetro) * (semiPerimetro - ladoA) * (semiPerimetro - ladoB) * (semiPerimetro - ladoC));
	}
}
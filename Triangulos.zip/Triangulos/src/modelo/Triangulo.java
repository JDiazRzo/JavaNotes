package modelo;

public abstract class Cuadrilatero {
	protected double lado1;
	protected double lado2;
	protected double lado3;
	protected double lado4;
	protected double angulo12;
	protected double angulo23;
	protected double angulo34;
	protected double angulo41;
	
	public Cuadrilatero(double lado1, double lado2, double lado3, double lado4) {
			this.lado1 = lado1;
			this.lado2 = lado2;
			this.lado3 = lado3;
			this.lado4 = lado4;
		}
	
	public Cuadrilatero(double lado1, double lado2, double lado3, double lado4, double angulo12, double angulo23,
		double angulo34, double angulo41) {
		this.lado1 = lado1;
		this.lado2 = lado2;
		this.lado3 = lado3;
		this.lado4 = lado4;
		this.angulo12 = angulo12;
		this.angulo23 = angulo23;
		this.angulo34 = angulo34;
		this.angulo41 = angulo41;
	}

	public double calcularPerimetro() {
		return(lado1+ lado2 +lado3 +lado4);
	}
	public  double calcularArea() {
		return 0;
	}
	
}

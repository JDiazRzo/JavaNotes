package modelo;

public class Rectangulo extends Paralelogramo {
	
	public Rectangulo (double base ,double altura){
		super(altura, base, altura);

	}
		

}